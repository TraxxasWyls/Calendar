//
//  ModuleOutput.swift
//  Workzilla
//
//  Created by incetro on 27/11/2019.
//  Copyright © 2017 Incetro. All rights reserved.
//

import Foundation

// MARK: - ModuleOutput

protocol ModuleOutput: class {
}
